<?php
return md5(md5(md5($pwd).md5($salt)).'1807a');