<table border="1">

            <tr>
                <td>ID</td>
                <td>名称</td>
                <td>分类</td>
                <td>描述</td>
                <td>是否火热</td>
                <td>是否上架</td>
                <td>编辑</td>
            </tr>
            
            @foreach($arr as $k=>$v)
            <tr del_id={{$v->goods_id}}>
                <td>{{$v->goods_id}}</td>
                <td><span class="goods_name">{{$v->goods_name}}</span></td>
                <td>{{$v->type_id}}</td>
                <td>{{$v->goods_desc}}</td>
                <td>@if($v->is_hot==1)是@else否@endif</td>
                <td>@if($v->is_in==1)是@else否@endif</td>
                <td><a href="javascript:;" class="del">删除</a>
                    <a href="javascript:;" class="updata">修改</a> 
                </td>
            </tr>
            @endforeach
            
        </table>