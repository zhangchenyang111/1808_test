<?php

namespace App\Http\Controllers;
use App\models\Login;
use App\models\Goods;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class Index extends Controller
{
     //注册
    public function doadd(Request $request){
            $data=$request->input();
            $name=$data['name'];
            $pwd=$data['pwd'];
            $cpwd=md5($pwd);
            $conpwd=$data['conpwd'];


            $code=$data['code'];
            $time=time();
            $codewhere=[
                'tel'=>$name,
                'code'=>$code,
                'status'=>1
            ];
            // $sql="select * from code where tel=$name and code=$code and timeout>$time and `status`=1";
            $arrinfo=DB::table('code')->where($codewhere)->first();
            if($arrinfo){
                if($time>$arrinfo->timeout){
                    $nul=[
                        'status'=>0,
                        'msg'=>'验证码失效'
                    ];
                    return $nul;
                }
            }else{
                $nul=[
                    'status'=>0,
                    'msg'=>'验证码错误'
                ];
                return $nul;
            }
            // if(empty($arrinfo->id)){
            //     $arr=array(
            //         'status'=>0,
            //         'msg'=>'验证码有误或者已经失效',
            //     );
            //     return $arr;
            // }


            if($pwd!=$conpwd){
                $arr = array(
                    'status'=>0,
                    'msg'=>"密码不一样",
                );
                return $arr;
            }
            $res=Login::where('name',$name)->first();
            if(!empty($res)){
                $arr=array(
                    'status'=>0,
                    'msg'=>"手机号已被注册",
                );
                return $arr;
            }

            $datainfo=[
                'name'=>$name,
                'pwd'=>$cpwd
            ];
        
            $sql=Login::insert($datainfo);
            if($sql){
                $arr=array(
                    'status'=>1,
                    'msg'=>'注册成功'
                );
                return $arr;
            }else{
                $arr=array(
                    'status'=>0,
                    'msg'=>'注册失败'
                );
                return $arr;
            }
    }  
     //登陆
    public function login(Request $request){
        $data=$request->input();
            $name=$data['name'];
            $pwd=$data['pwd'];
            $cpwd=md5($pwd);
            $datawhere=[
                'name'=>$name,
                'pwd'=>$cpwd
            ]; 
            $res=DB::table('Login')->where($datawhere)->first();
            if($res){
                $id=$res->id;
                $name=$res->name;
                session(['uid'=>$id,'name'=>$name]);
                $arr=[
                    'status'=>1,
                    'msg'=>'登陆成功'
                ];
                return $arr;
            }else{
                $arr=[
                    'status'=>0,
                    'msg'=>'登陆失败'
                ];
                return $arr;
            }

    }
    //首页潮人品牌
    public function index(){
        $sql2='select * from shop_goods where is_tell=1 limit 2';
        $data=DB::select($sql2);
        return view('order.index',['data'=>$data]);
    }
    //验证码
    public function code(Request $request){
      $tel=$request->input('tel');
      $num = rand(1000,9999);
      //   $obj=new \send();
      //   $bol=$obj->show($tel,$num);
      $bol=100;
      if($bol == 100){
          $arr=array(
              'tel'=>$tel,
              'code'=>$num,
              'timeout'=>time()+60,
              'status'=>1,
          );
        $bol=DB::table('code')->insert($arr);
        var_dump($bol);
      }
    }
    //页面加载单间（不算项目）
    public function demo(){
        return view('order.demo');
    }
    //页面加载商品数据
    public function addli(Request $request){
       $arr=array();
       $page=$request->input('page',1);
       $pageNum=2;
       $offset=($page-1)*$pageNum;
       $arrdatainfo=DB::table('shop_goods')->offset($offset)->limit($pageNum)->get();//每页数据
       $totaldata=DB::table('shop_goods')->count();//总页数
       $pagetotal=ceil($totaldata/$pageNum);//总页数
       $objview=view('order.goodsli',['arrdatainfo'=>$arrdatainfo]);
       $content = response($objview)->getContent();
       
       $arr['info']=$content;
       $arr['total']=$pagetotal;

       return $arr;
    }
    //分类
    public function allshops(){
        $arr=DB::table('shop_goods')->get();
        $data=DB::table('category')->where(['pid'=>0])->get();
        
         //print_r($data);die;
        return view('order.allshops',['arr'=>$arr,'data'=>$data]);
    }   
     
    public function catet(Request $request){
        $array=array();
        $cate_id=$request->input('cate_id');
        $arr=DB::table('shop_goods')->where('cate_id',$cate_id)->get();

        $view=view('order.show',['arr'=>$arr]);
        $content = response($view)->getContent();
        $array['info']=$content;

        return $array;


    } 
    //商品详情
    public function shopcontent(Request $request){
         $goods_id=$request->input('goods_id');
         //echo $goods_id;die;
         $arr=DB::table('shop_goods')->where('goods_id',$goods_id)->get();
         $data=DB::table('cart')->pluck('buy_number')->toArray();
         $app=array_sum($data);
         //print_r($arr);die;
         return view('order.shopcontent',['arr'=>$arr])->with(['app'=>$app]);
    }
    public function islogin(Request $request){
        //接受数据
        $goods_id=$request->input('goods_id');
        $buy_number=$request->input('buy_number');
        //验证商品是否为空
        if(empty($goods_id)){
            $arrinfo=[
                'status'=>0,
                'msg'=>'商品不存在'
            ];
            return $arrinfo;
        }
        //取session判断是否登陆
        $session=Session('uid');
        if(empty($session)){
           $arr=[
               'status'=>1,
               'msg'=>'请先登录'
           ];
           return $arr;
        }
        //查询购物表数据
        $res1=DB::table('cart')->where('goods_id',$goods_id)->first();
        if(empty($res1)){
            //判断库存
            $res=Goods::where('goods_id',$goods_id)->first();
            $goods_store=$res['goods_store'];
            if($buy_number>$goods_store){
                $arr=[
                    'status'=>0,
                    'msg'=>'购买数量不能大于最大库存'
                ];
                return $arr;
            }
            //入库
            $datainfo=[
                'goods_id'=>$goods_id,
                'id'=>$session,
                'buy_number'=>$buy_number,
                'create_time'=>time()
            ];

            $data=DB::table('cart')->insert($datainfo);
            $where=[
                'status'=>1
            ];
            $data=DB::table('cart')->where($where)->pluck('buy_number')->toArray();
            $app=array_sum($data);

            if($data){
                $arr=[
                    'status'=>2,
                    'msg'=>'加入购物车成功',
                    'num'=>$app
                ];
                return $arr;
            }
        }else{
            //累加
            //数据库现有的库存
            $buy_number1=$res1->buy_number;
            //库存+1
            $buy_number2=$buy_number1+1;
            $res=Goods::where('goods_id',$goods_id)->first();
            $goods_store=$res['goods_store'];
            if($buy_number2>$goods_store){
                $arr=[
                    'status'=>0,
                    'msg'=>'商品购买数量不能大于最大库存'
                ];
                return $arr;
            }
            //入库
            $datainfo=[
                'id'=>$session,
                'buy_number'=>$buy_number2,
                'create_time'=>time(),
                //'buy_number'=>0

            ];
            $data=DB::table('cart')->where('goods_id',$goods_id)->update($datainfo);
            $data=DB::table('cart')->where(['status'=>1,'id'=>$session])->pluck('buy_number')->toArray();
            $app=array_sum($data);
            if($data){
                $arr=[
                    'status'=>2,
                    'msg'=>'加入购物车成功',
                    'num'=>$app
                ];
                return $arr;
            }
            
            
        }
        

        
    }
    //购物车表
    public function shopcart(){
        $where=[
            'status'=>1
        ];
        $arr=DB::table('cart')
        ->join('shop_goods','cart.goods_id','=','shop_goods.goods_id')
        ->where($where)->get();
        $sql='select * from shop_goods where goods_hot=1 limit 4';
        $data=DB::select($sql);
        return view('order.shopcart',['arr'=>$arr,'data'=>$data]);
    }
    //购买数量文本框失焦
    public function shopBlur(Request $request){
        $type=$request->input('type');
        $goods_id=$request->input('goods_id');
        // $goods_id=implode('',$goods_id);
        $res1=DB::table('shop_goods')->where('goods_id',$goods_id)->first();
        $goods_store=$res1->goods_store;
        if($type<=$goods_store && $type>=1){
            $updatewhere=[
                'buy_number'=>$type
            ];
            $res=DB::table('cart')->where('goods_id',$goods_id)->update($updatewhere);
            if($res){
                $arr=['status'=>1,'msg'=>'商品数量修改成功'];
                return $arr;
            }
        }else if($type<=0){
            $arr=['status'=>0,'msg'=>'商品数量最小为1'];
            return $arr;
        }else{
            $arr=['status'=>0,'msg'=>'商品购买数量不能大于最大库存'];
            return $arr;
        }
        
    }
    /**加减号修改数据库 */
    public function shopNum(Request $request){
        $type=$request->input('type');
        $goods_id=$request->input('goods_id');
        // echo $type;echo $goods_id;die;
        //查询当前库存
        $res=DB::table('cart')->where('goods_id',$goods_id)->first();
        $res1=DB::table('shop_goods')->where('goods_id',$goods_id)->first();
        
        $goods_store=$res1->goods_store;
        $buy_number=$res->buy_number;
        if($type==1){
            if($buy_number+1<=$goods_store){
                $numberWhere = [
                'buy_number' => $buy_number+1
            ];
            DB::table('cart')->where('goods_id',$goods_id)->update($numberWhere);
            }else{
                $arr=[
                    'status'=>0,
                    'msg'=>'商品购买数量不能超过最大库存',
                  
                ];
                return $arr;
            }
            
        }else{
            $numberWhere = [
                'buy_number' => $res->buy_number-1
            ];
            DB::table('cart')->where('goods_id',$goods_id)->update($numberWhere);
        }
    }
    //批量删除
    public function cartDel(Request $request){
        $goods_id=$request->input('goods_id');
        $uid=$request->session()->get('uid');
        $cartwhere=[
            'status'=>0,
            'buy_number'=>0,
             'create_time'=>time()
        ];
        $res=DB::table('cart')->where('id',$uid)->whereIn('goods_id',$goods_id)->update($cartwhere);
        if($res){
            $arr=['status'=>1,'msg'=>'删除成功'];
            return $arr;
        }else{
            $arr=['status'=>0,'msg'=>'删除失败'];
            return $arr;
        }
        
        

    }
    //单删
    public function del(Request $request){
        $cart_id=$request->input('cart_id');
        $datainfo=[
            'status'=>0,
            'buy_number'=>0
        ];
        $res=DB::table('cart')->where('cart_id',$cart_id)->update($datainfo);
        if($res){
            $array=[
                'status'=>1,
                'msg'=>'删除成功'
            ];
            return $array;
        }

    }
    //总结算
    public function orderDo(Request $request){
        $goods_id=$request->input('goods_id');
       $price=$request->input('price');//
       $order_amount=trim($price,'￥');
        //var_dump($order_amount) ;die;
        $uid=session('uid');
        if(empty($uid)){
            $arr=['status'=>1,'msg'=>'请先登录'];
            return $arr;
        }
        if(empty($goods_id)){
            $arr=['status'=>0,'msg'=>'选择商品不能为空'];
            return $arr;
        } 
        $where=[
            'status'=>1
        ];
        $arr=DB::table('cart')
        ->join('shop_goods','cart.goods_id','=','shop_goods.goods_id')
        ->where($where)
        ->whereIn('shop_goods.goods_id',$goods_id)
        ->get();
        
        //生成订单号
        $order_no = date("YmdHis",time()).rand(1000,9999);
        $addwhere=[
            'order_no'=>$order_no,
            'order_amount'=>$order_amount,
            'id'=>$uid,
        ];
        $res=DB::table('order')->insert($addwhere);
       
         $res2=DB::table('order')->where('order_no',$order_no)->get(['order_id']);
          $order_id=$res2[0]->order_id;
         $uid=session('uid');
         foreach($arr as $v){
           $arr1=[
                'id'=>$uid,
                'order_id'=>$order_id,
                'goods_id'=>$v->goods_id,
                'goods_name'=>$v->goods_name,
                'goods_selfprice'=>$v->goods_selfprice,
                'goods_img'=>$v->goods_img,
                'buy_number'=>$v->buy_number,
                'goods_status'=>1,
                'order_no'=>$order_no,
                'create_time'=>time()
           ];
           DB::table('order_detail')->insert($arr1);
       }

       $res1=DB::table('cart')->whereIn('goods_id',$goods_id)->where('id',$uid)->update(['status'=>0,'buy_number'=>0]);
        if($res1){
            $arr=[
                'status'=>2,
                'msg'=>'进入订单详情',
                'order_id'=>$order_id
            ];
            return $arr;
        }
        

        

    }
    public function payment(Request $request){
        $order_id=$request->input('order_id');
        $arr=DB::table('order_detail')->where('order_id',$order_id)->get();
        
        
        return view('order.payment',['arr'=>$arr]);
    }
    //地址添加
    public function addressadd(){
        return view('order.addressadd');
    } 
    public function addressdo(Request $request){
        $arr=$request->input();
        $address_name=$arr['address_name'];
        $address_tel=$arr['address_tel'];
        $address_address=$arr['address_address'];
        $status=$arr['status'];
        $uid=session('uid');
        if($status==1){
          DB::table('address')->where('id',$uid)->update(['status'=>0]);
        }
       // print($address_tel);die;
       $uid=session('uid');
        $where=[
            'id'=>$uid,
            'address_name'=>$address_name,
            'address_tel'=>$address_tel,
            'address_address'=>$address_address,
            'status'=>$status
        ];
        $res=DB::table('address')->insert($where);
        if($res){
            $arr=[
                'status'=>1,
                'msg'=>'保存地址成功'
            ];
            return $arr;
        }
        
    }
    //地址展示
    public function address(){
        $data=DB::table('address')->get();
        return view('order.address',['data'=>$data]);
    }
    //地址删除
    public function addressdelete(Request $request){
        $del_id=$request->input('del_id');
        $res=DB::table('address')->where('address_id',$del_id)->delete();
        if($res){
            $arr=['status'=>1,'msg'=>'删除成功'];
            return $arr;
        }else{
            $arr=['status'=>0,'msg'=>'删除失败'];
            return $arr;
        }
        
    }
    //地址修改
    public function addressupdate(Request $request){
        $update_id=$request->input('update_id');
        $res=DB::table('address')->where('address_id',$update_id)->first();
        return view('order.addressupdate',['res'=>$res]);

    }
    public function addressupdatedo(Request $request){
        $arr=$request->input();
        $address_id=$request->input('address_id');
        //$address_id=$arr['address_id'];
        $address_name=$arr['address_name'];
        $address_tel=$arr['address_tel'];
        $address_address=$arr['address_address'];
       
        $where=[
            'address_name'=>$address_name,
            'address_tel'=>$address_tel,
            'address_address'=>$address_address,
        ];
        $res=DB::table('address')->where('address_id',$address_id)->update($where);
        if($res){
            $arr=[
                  'status'=>1,
                  'msg'=>'修改成功'
            ];
            return $arr;
            
        }else{
            $arr=[
                'status'=>0,
                'msg'=>'修改失败'
          ];
          return $arr;
        }
    }
    //设为默认
    public function moren(Request $request){
        $address_id=$request->input('address_id');
        $uid=session('uid');
        DB::table('address')->where('id',$uid)->update(['status'=>0]);
        $res=DB::table('address')->where('address_id',$address_id)->update(['status'=>1]);
        if($res){
            $arr=[
                'status'=>1,
                'msg'=>'设为默认成功'
            ];
            return $arr;
        }

    }
    //我的潮购
    public function buycart(){
        $sql='select * from shop_goods where goods_hot=1 limit 4';
        $data=DB::select($sql);
        return view('order.buycart',['data'=>$data]);
    }


}
