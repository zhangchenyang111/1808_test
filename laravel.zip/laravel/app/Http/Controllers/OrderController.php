<?php

namespace App\Http\Controllers;
use App\models\Goods;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    //查询分类表
    public function select(){
        $sql='select * from type';
        $arr=DB::select($sql);
        //var_dump($arr);die;
        return view('order.order',['arr'=>$arr]);
        //var_dump($arr);die;
    }
    //添加
    public function add(Request $request){
        $data=$request->input();
        $res=DB::table('goods')->insert($data);
        if($res){
            echo 1;
        }else{
            echo 2;
        }
    }
    //展示
    public function list(){
        $arr=DB::table('goods')
           ->join('type','goods.type_id','=','type.type_name')
           ->where('is_del','=','1')
           ->select()
           ->paginate(2);
        return view('order.list',['arr'=>$arr]);
    }
    //删除假删
    public function delete(Request $request){
        $del_id=$request->input('del_id');
        
        $sql="update goods set is_del=2 where goods_id=$del_id";
        $res=DB::update($sql);
        if($res){
            echo 1;
        }else{
            echo 2;
        }    
    }
    //修改
    public function updata(Request $request){
        $updata_id=$request->input('updata_id');
        $where=[
            'goods_id'=>$updata_id
        ];
        $arr=Goods::where($where)->get();
        // print_r($arr);die;
        $sql='select * from type';
        $data=DB::select($sql);
        //print_r($data);die;
        return view('order.updata',['arr'=>$arr],['data'=>$data]);



    }
    //修改入表
    public function updatado(Request $request){
        $data=$request->input();
        $goods_id=$request->input('goods_id');
        $where=[
            'goods_id'=>$goods_id
        ];
        $res=DB::table('goods')->where($where)->update($data);
        if($res){
            echo 1;
        }else{
            echo 2;
        }
    }
    //即点即改
    public function gai(Request $request){
    	$post=$request->input();
        $sql=DB::table('goods')
            ->where("goods_id",$post['goods_id'])
            ->update(['goods_name'=>$post['goods_name']]);
            if($sql){
                return [
                    'success' => true,
                    'msg' => '修改成功'
                ];
            }else{
                return [
                    'success' => false,
                    'msg' => '修改失败'
                ];
            }
    }
    //搜索
    public function search(Request $request){
        $data=$request->input('sform');
        $arr=DB::table('goods')->where('goods_name',$data)->get();
        return view('order.search',['arr'=>$arr]);

    }

}
