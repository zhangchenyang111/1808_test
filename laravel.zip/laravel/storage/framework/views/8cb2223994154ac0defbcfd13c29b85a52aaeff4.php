<table border="1">

            <tr>
                <td>ID</td>
                <td>名称</td>
                <td>分类</td>
                <td>描述</td>
                <td>是否火热</td>
                <td>是否上架</td>
                <td>编辑</td>
            </tr>
            
            <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr del_id=<?php echo e($v->goods_id); ?>>
                <td><?php echo e($v->goods_id); ?></td>
                <td><span class="goods_name"><?php echo e($v->goods_name); ?></span></td>
                <td><?php echo e($v->type_id); ?></td>
                <td><?php echo e($v->goods_desc); ?></td>
                <td><?php if($v->is_hot==1): ?>是<?php else: ?>否<?php endif; ?></td>
                <td><?php if($v->is_in==1): ?>是<?php else: ?>否<?php endif; ?></td>
                <td><a href="javascript:;" class="del">删除</a>
                    <a href="javascript:;" class="updata">修改</a> 
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>