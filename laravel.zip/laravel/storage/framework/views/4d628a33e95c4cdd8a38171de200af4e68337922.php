<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="/js/jquery.js"></script>
</head>
<body>
    <form method="post" onsubmit='return false'>
        <input type="hidden" name="goods_id" id="goods_id" value="<?php echo e($arr[0]['goods_id']); ?>">
        <table border="1">
            <tr>
                <td>名称</td>
                <td><input type="text" name="goods_name" id="goods_name" value='<?php echo e($arr[0]['goods_name']); ?>'></td>
            </tr>
            <tr>
                <td>分类</td>
                <td>
                    <select name="" id="type">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <option value="<?php echo e($v->type_name); ?>"><?php echo e($v->type_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>描述</td>
                <td><input type="text" name="goods_desc" id="goods_desc" value="<?php echo e($arr[0]['goods_desc']); ?>"></td>
            </tr>
            <tr>
                <td>是否热卖</td>
                <td>
                    <input type="radio" name="is_hot" value="1" <?php if($arr[0]['is_hot']==1): ?> checked <?php endif; ?>>是
                    <input type="radio" name="is_hot" value="2" <?php if($arr[0]['is_hot']==2): ?> checked <?php endif; ?>>否
               </td>
            </tr>
            <tr>
                <td>是否上架</td>
                <td>
                    <input type="radio" name="is_in" value="1" <?php if($arr[0]['is_in']==1): ?> checked <?php endif; ?>>是
                    <input type="radio" name="is_in" value="2" <?php if($arr[0]['is_in']==2): ?> checked <?php endif; ?>>否
                </td>
            </tr>
            <tr>
                <td><input type="submit" value="修改" id="s"></td>
            </tr>
        </table>
    </form>
</body>
</html>
<script>
    $(function(){
        $('#s').click(function(){
        var goods_id=$('#goods_id').val();
        var goods_name=$('#goods_name').val();
        var type=$('#type').val();
        var goods_desc=$('#goods_desc').val();
        var is_hot=$("input[name='is_hot']:checked").val();
        var is_in=$("input[name='is_in']:checked").val();
        $.ajax({
            url:'updatado',
            data:{goods_id:goods_id,goods_name:goods_name,type_id:type,goods_desc:goods_desc,is_hot:is_hot,is_in:is_in},
            method:'post',
        }).done(function(res){
             if(res==1){
                 alert('修改成功');
                 location.href='list';
             }else{
                 alert('未修改');
                 location.href='updata?goods_id='+goods_id;
             }
        })
      })
    })
</script>