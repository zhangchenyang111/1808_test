<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
    table{border:1px solid #666;border-collapse: collapse;width:900px;margin:10px auto;font-size: 14px;color:#666;}
    th,td{border:1px solid #666;height:25px;text-align:center;}
    a{border:1px solid #666;text-decoration: none;padding: 0 5px;border-radius: 5px;color:#666;}
    a:hover,a.current{border:1px solid plum;color:plum;}
    ul li{
        text-decoration: none;
        padding: 0 5px;
        border-radius: 5px;
        color:orange;
        list-style:none;
        float:left;
        font-size:20px;
        margin-left:10px;
     }
    ul li a{
        text-decoration: none;
    }
    ul{
        margin-left:400px;
     }
</style>

</head>
<body>
    <form id="search">
        <input type="text" id="sc" name="search">
        <input type="button" id="but" value="搜索">
    </form>
    <form action="">
        <div class="container">
        <table border="1">

            <tr>
                <td>ID</td>
                <td>名称</td>
                <td>分类</td>
                <td>描述</td>
                <td>是否火热</td>
                <td>是否上架</td>
                <td>编辑</td>
            </tr>
            
            <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr del_id=<?php echo e($v->goods_id); ?>>
                <td><?php echo e($v->goods_id); ?></td>
                <td><span class="goods_name"><?php echo e($v->goods_name); ?></span></td>
                <td><?php echo e($v->type_name); ?></td>
                <td><?php echo e($v->goods_desc); ?></td>
                <td><?php if($v->is_hot==1): ?>是<?php else: ?>否<?php endif; ?></td>
                <td><?php if($v->is_in==1): ?>是<?php else: ?>否<?php endif; ?></td>
                <td><a href="javascript:;" class="del">删除</a>
                    <a href="javascript:;" class="updata">修改</a> 
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
        </div>
        <?php echo e($arr->links()); ?>

    </form>
</body>
</html>
<script src="/js/jquery.js"></script>
<script>
    $(function(){
        //删除
        $('.del').click(function(){
            _this=$(this)
            var del_id=_this.parents('tr').attr('del_id');
            //console.log(del_id);
            $.ajax({
            url:'delete',
            data:{del_id:del_id7},
            method:'post',
         }).done(function(res){
             if(res==1){
                 alert('删除成功');
                 location.href='list';
             }else{
                 alert('删除失败');
                 location.href='list';
             }
         })
        })
        //修改
        $('.updata').click(function(){
            var _this=$(this)
            var updata_id=_this.parents('tr').attr('del_id')
            //console.log(updata_id);
            location.href='updata?updata_id='+updata_id;
        })
        //即点即改
        $(document).on("click",".goods_name",function(){
   		 var goods_name=$(this).text();//span标签用text()获取值
            //alert(goods_name);
            
            //把文本换成input框
            $(this).parent().html("<input type='text' name='goods_name' value="+goods_name+">");
            })
            $(document).on("blur","[name='goods_name']",function(){  
            // 获取修改后的值
            var field = $(this).val();
            //alert(field);
            // 判断非空
            if(field == ''){
                alert('名称不能为空');
                return ;
            }
            // 获取所属数据主键Id
            var goods_id=$(this).parent().parent().attr('del_id');
            //alert(id);
            // 将input转换为span,并将要修改值赋给span标签
            $(this).parent().html("<span class='goods_name'>"+field+"</span>");
            $.ajax({
            method:"POST",
            url:"gai",
            data:{goods_name:field,goods_id:goods_id},
            dataType:'json'
            }).done(function( msg ){
            //console.log(msg);
            alert(msg.msg);
          });
        })
        //搜索
        $('#but').click(function(){
            var sform=$('#sc').val();
            //console.log(sform);
            $.post(
                'search',
                {sform:sform},
                function(msg){
                    $('.container').empty();
                    $('.container').html(msg);

                }
            )
        });
            
        
            

        
        
        
        
        })




</script>