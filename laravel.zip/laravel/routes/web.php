<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//基本路由
Route::get('/',function(){
     echo '222';
});
//路由映射控制器
Route::get('order','OrderController@order');
//显示视图
Route::get('order1',function(){
    return view('order.order');
});
//路由加判断+路由重定向
Route::get('order1/{id}',function($id){
     if($id<3){
         return redirect('http://www.baidu.com');
     }
});
//控制器接收参数
Route::get('show','OrderController@show');
//前缀
Route::prefix('admin')->group(function () {
    Route::get('order3', function () {
       echo 6666;
    });
Route::get('order4','OrderController@order');


});

Route::get('order7','OrderController@insert');
Route::get('select','OrderController@select');
Route::post('add','OrderController@add');
Route::get('list','OrderController@list');
Route::post('delete','OrderController@delete');
Route::get('updata','OrderController@updata');
Route::post('updatado','OrderController@updatado');
Route::post('gai','OrderController@gai');
Route::post('search','OrderController@search');
Route::get('index','index@index');
Route::get('login',function(){
    return view('order.login');
});
Route::get('register',function(){
    return view('order.register');
});

Route::get('test','index@test')->middleware('test');
Route::post('doadd','index@doadd');
Route::post('login','index@login');
Route::get('index1','index@index');
Route::post('code','index@code');
Route::get('demo','index@demo');
Route::post('addli','index@addli');
Route::get('allshops','index@allshops');
Route::any('catet','index@catet');
Route::any('shopcontent','index@shopcontent');
Route::get('array','index@array');
Route::any('islogin','index@islogin');
Route::any('shopcart','index@shopcart');
Route::any('del','index@del');
Route::any('shopNum','index@shopNum');
Route::any('shopBlur','index@shopBlur');
Route::any('cartDel','index@cartDel');
Route::any('orderDo','index@orderDo');
Route::any('payment','index@payment');
Route::any('address','index@address');
Route::any('addressadd','index@addressadd');
Route::any('addressdo','index@addressdo');
Route::any('address','index@address');
Route::any('addressdelete','index@addressdelete');
Route::any('addressupdate','index@addressupdate');
Route::any('addressupdatedo','index@addressupdatedo');
Route::any('moren','index@moren');
Route::any('buycart','index@buycart');

